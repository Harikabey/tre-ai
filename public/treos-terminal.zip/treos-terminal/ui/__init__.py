"""TreOS Terminal Textual ekranları."""
